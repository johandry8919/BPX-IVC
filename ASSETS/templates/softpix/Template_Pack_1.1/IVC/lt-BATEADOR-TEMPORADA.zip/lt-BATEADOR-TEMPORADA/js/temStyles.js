

const Fondo_equipos = [
    { id_equipo: 0, img_url: "" },
    { id_equipo: 1, img_url: "./fondo_equipos/logo_team_1.png" },
    { id_equipo: 2, img_url: "./fondo_equipos/logo_team_2.png" },
    { id_equipo: 3, img_url: "./fondo_equipos/logo_team_3.png" },
    { id_equipo: 4, img_url: "./fondo_equipos/logo_team_4.png" },
    { id_equipo: 5, img_url: "./fondo_equipos/logo_team_5.png" },
    { id_equipo: 6, img_url: "./fondo_equipos/logo_team_6.png" },
    { id_equipo: 7, img_url: "./fondo_equipos/logo_team_7.png" },
    { id_equipo: 8, img_url: "./fondo_equipos/logo_team_8.png" },
  ];

const Barra_equipos = [
    { id_equipo: 0, img_url: "" },
    { id_equipo: 1, img_url: "./barra_equipos/logo_team_1.png" },
    { id_equipo: 2, img_url: "./barra_equipos/logo_team_2.png" },
    { id_equipo: 3, img_url: "./barra_equipos/logo_team_3.png" },
    { id_equipo: 4, img_url: "./barra_equipos/logo_team_4.png" },
    { id_equipo: 5, img_url: "./barra_equipos/logo_team_5.png" },
    { id_equipo: 6, img_url: "./barra_equipos/logo_team_6.png" },
    { id_equipo: 7, img_url: "./barra_equipos/logo_team_7.png" },
    { id_equipo: 8, img_url: "./barra_equipos/logo_team_8.png" },
  ];
const Lineup = [
    { id_equipo: 0, img_url: "" },
    { id_equipo: 1, img_url: "./lineaup/logo_team_1.png" },
    { id_equipo: 2, img_url: "./lineaup/logo_team_2.png" },
    { id_equipo: 3, img_url: "./lineaup/logo_team_3.png" },
    { id_equipo: 4, img_url: "./lineaup/logo_team_4.png" },
    { id_equipo: 5, img_url: "./lineaup/logo_team_5.png" },
    { id_equipo: 6, img_url: "./lineaup/logo_team_6.png" },
    { id_equipo: 7, img_url: "./lineaup/logo_team_7.png" },
    { id_equipo: 8, img_url: "./lineaup/logo_team_8.png" },
  ];
const alta_baja = [
    { id_equipo: 0, img_url: "./img/baja.png" },
    { id_equipo: 0, img_url: "./img/alta.png" },
    
  ];
const video_media = [
  { id_equipo: 0, img_url: "" },
  { id_equipo: 1, img_url: "./media/logo_team_1.webm" },
  { id_equipo: 2, img_url: "./media/logo_team_2.webm" },
  { id_equipo: 3, img_url: "./media/logo_team_3.webm" },
  { id_equipo: 4, img_url: "./media/logo_team_4.webm" },
  { id_equipo: 5, img_url: "./media/logo_team_5.webm" },
  { id_equipo: 6, img_url: "./media/logo_team_6.webm" },
  { id_equipo: 7, img_url: "./media/logo_team_7.webm" },
  { id_equipo: 8, img_url: "./media/logo_team_8.webm" },
    
  ];


 
